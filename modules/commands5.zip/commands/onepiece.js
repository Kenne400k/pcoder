 /**
* @author CallmeSun
* @warn Vui lòng không sửa credits cảm ơn !
*/
module.exports.config = {
  name: "onepiece",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Ken",
  description: "video One Piece",
  commandCategory: "Video",
  usages: "girlnude",
  cooldowns: 5,
  dependencies: {
    "request":"",
    "fs-extra":"",
    "axios":""
  }
};

module.exports.run = async({api,event,args,client,Users,Threads,__GLOBAL,Currencies}) => {
const axios = global.nodemodule["axios"];
const request = global.nodemodule["request"];
const fs = global.nodemodule["fs-extra"];
  var link = [
"https://i.imgur.com/g2k1KQb.mp4",
"https://i.imgur.com/Ti7rUf4.mp4",   
"https://i.imgur.com/148Wmvh.mp4", 
"https://i.imgur.com/QuHmydh.mp4",   
"https://i.imgur.com/i8Pui2Q.mp4",
"https://i.imgur.com/YmEuCnF.mp4",
"https://i.imgur.com/rZhyNFP.mp4",
"https://i.imgur.com/B43tO8V.mp4",
"https://i.imgur.com/gN6rJCJ.mp4",
"https://i.imgur.com/w1Vs660.mp4",
"https://i.imgur.com/BYnXJDL.mp4",
"https://i.imgur.com/znnhnbr.mp4",
"https://i.imgur.com/WncBBsn.mp4",
  ];
  var max = Math.floor(Math.random() * 6);  
  var min = Math.floor(Math.random() * 2);
  var data = await Currencies.getData(event.senderID);
  var exp =  data.exp;
  var money = data.money
      if(money < 100) api.sendMessage("Bạn cần 100 đô để xem video:V",event.threadID,event.messageID)
          else {
   Currencies.setData(event.senderID, options = {money: money - 100})
   var callback = () => api.sendMessage({body:`==𝐁𝐀̣𝐍 Đ𝐀̃ Đ𝐔̉ 𝟏𝟎𝟎 Đ𝐎̂==\n==𝐍𝐄̂𝐍 𝐂𝐎́ 𝐓𝐇𝐄̂̉ 𝐗𝐄𝐌==\n🌸 ━━━━━━━━━━━━━ 🌸\n====「 𝐓𝐇𝐀̀𝐍𝐇 𝐕𝐈𝐄̂𝐍 𝐁𝐀̆𝐍𝐆 𝐌𝐔̃ 𝐑𝐎̛𝐌 」====\n𝟙. 𝐌𝐨𝐧𝐤𝐞𝐲 𝐃. 𝐋𝐮𝐟𝐟𝐲 👒 \n𝟚. 𝐑𝐨𝐫𝐨𝐧𝐨𝐚 𝐙𝐨𝐫𝐨 ⚔️\n𝟛. 𝐍𝐚𝐦𝐢 🍊\n𝟜. 𝐔𝐬𝐨𝐩𝐩 🔫\n𝟝. 𝐒𝐚𝐧𝐣𝐢 🍽️\n𝟞. 𝐓𝐨𝐧𝐲 𝐓𝐨𝐧𝐲 𝐂𝐡𝐨𝐩𝐩𝐞𝐫 💊\n𝟟. 𝐍𝐢𝐜𝐨 𝐑𝐨𝐛𝐢𝐧 📖\n𝟠. 𝐅𝐫𝐚𝐧𝐤𝐲 🔨\n𝟡. 𝐁𝐫𝐨𝐨𝐤 🎸\n𝟙𝟘. 𝐉𝐢𝐧𝐛𝐞 🐟 \n🌸 ━━━━━━━━━━━━━ 🌸 \n===「 𝐓𝐀̀𝐔 𝐁𝐀̆𝐍𝐆 𝐌𝐔̃ 𝐑𝐎̛𝐌 」===\n𝟙𝟙. 𝐆𝐨𝐢𝐧𝐠 𝐌𝐞𝐫𝐫𝐲 ⛵\n𝟙𝟚. 𝐓𝐡𝐨𝐮𝐬𝐚𝐧𝐝 𝐒𝐮𝐧𝐧𝐲 ⛵\n\n𝐋𝐮̛𝐮 𝐲́: 𝐊𝐡𝐨̂𝐧𝐠 𝐜𝐨́ 𝐚̉𝐧𝐡 đ𝐚̂𝐮 𝐦𝐚̀ 𝐫𝐞𝐩𝐥𝐲🥲`,attachment: fs.createReadStream(__dirname + "/cache/5.mp4")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/5.mp4"));
let name = await Users.getNameUser(event.senderID);
    let mentions = [];
    mentions.push({
      tag: name,
      id: event.senderID
    })            
      return request(encodeURI(link[Math.floor(Math.random() * link.length)])).pipe(fs.createWriteStream(__dirname+"/cache/5.mp4")).on("close",() => callback());
   }
};
module.exports.config = {
	name: "loli",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "CHỊU ;-;",
	description: "FBI =))",
	commandCategory: "hình ảnh",
	usages: "loli",
	cooldowns: 3
};

module.exports .run = async ({ api, event, Currencies, Users, args}) => {
	const axios = require('axios');
	const request = require('request');
	const fs = require("fs");
	var content = args.join(" ");
	var money = (await Currencies.getData(event.senderID)).money
	if (money >= 200) {
     await Currencies.increaseMoney(event.senderID, parseInt(200))
		  const res = await axios.get('https://www.api-adreno.tk/loli')
    var callback = () => api.sendMessage({body:`FBIIII`,attachment: fs.createReadStream(__dirname + "/cache/loli.jpeg")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/loli.jpeg"),event.messageID);
	 return request(encodeURI(res.data.url)).pipe(fs.createWriteStream(__dirname+'/cache/loli.jpeg')).on('close',() => callback());
	} else return api.sendMessage("Bạn cần 200 đô để xem ảnh ?",event.threadID,event.messageID);
}
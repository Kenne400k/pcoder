exports.config = {
  name: 'anti',
  version: '1.0.0',
  hasPermssion: 1,
  credits: 'DC-Nam',
  description: '',
  commandCategory: 'Hệ Thống',
  usages: '[]',
  cooldowns: 3
};
let fs = require('fs');

let path = __dirname+'/cache/anti.json';
let data = {
  out: {},
  join: {},
  name: {},
  image: {},
  admin: {},
  nickname: {},
};
let save = ()=>fs.writeFileSync(path, JSON.stringify(data));
if (!fs.existsSync(path))save(); else data = require(path);

exports.run = async function(o) {
  let send = (msg, callback)=>o.api.sendMessage(msg, o.event.threadID, callback, o.event.messageID);
  let images = [
    "https://i.imgur.com/pNyt6Ei.jpg",
    "https://i.imgur.com/2sVVNna.jpg",
    "https://i.imgur.com/ZQ7uJ7N.jpg",
    "https://i.imgur.com/pNyt6Ei.jpg"
  ];
  let attachment = [];
  for (let i = 0; i < 4; i++)try {
    attachment.push(await streamURL(images[Math.random()*images.length<<0], 'jpg'))}catch {};

  send({
    body: `[=====[ ANTI ]=====]\n\n1. Không Cho Thành Viên Rời Nhóm.\n2. Không Cho Thành Viên Thêm Người Dùng Vào Nhóm.\n3. Không Cho Thành Viên Đổi Tên Nhóm.\n4. Không Cho Thành Viên Đổi Ảnh Nhóm.\n5. Không Cho Thành Viên Đổi Biệt Danh.\n6. Không Cho Thay Đổi QTV Nhóm\n\n-> Phản Hồi Kèm STT.`,
    attachment,
  }, (err, res)=> {
    res.name = exports.config.name;
    res.event = o.event;
    global.client.handleReply.push(res);
  });
};
exports.handleReply = function(o) {
  let tid = o.event.threadID;
  let send = (msg, callback)=>o.api.sendMessage(msg, tid, callback, o.event.messageID);

  switch (o.event.args[0]) {
    case '1': {
      let out = data.out[tid];
      if (!out)out = data.out[tid] = {};
      let {
        status,
      } = out;
      out.status = !!status?false: true;
      send(`Đã ${out.status?'bật': 'tắt'} chống thành viên rời nhóm.`);
    };
      break;
    case '2': {
      let join = data.join[tid];
      if (!join)join = data.join[tid] = {};
      let {
        status,
      } = join;
      join.status = !!status?false: true;
      send(`Đã ${join.status?'bật': 'tắt'} chống thành viên thêm người dùng vào nhóm.`);
    };
      break;
    case '3': {
      let name = data.name[tid];
      if (!name)name = data.name[tid] = {};
      let {
        status,
      } = name;
      name.status = !!status?false: true;
      send(`Đã ${name.status?'bật': 'tắt'} chống thành viên đổi tên nhóm.`);
    };
      break;
    case '5': {
      let nickname = data.nickname[tid];
      if (!nickname)nickname = data.nickname[tid] = {};
      let {
        status,
      } = nickname;
      nickname.status = !!status?false: true;
      send(`Đã ${nickname.status?'bật': 'tắt'} chống thành viên đổi biệt danh.`);
    };
      break;
    case '6': {
      let admin = data.admin[tid];
      if (!admin)admin = data.admin[tid] = {};
      let {
        status,
      } = admin;
      admin.status = !!status?false: true;
      send(`Đã ${admin.status?'bật': 'tắt'} chống thay đổi QTV nhóm..`);
    }
      break;

    default:
      break;
  };
  save();
};
exports.listen_mqtt_callback = async function(err, msg) {
  try {
    if (err)return;
    let thread_info = global.data.threadInfo.get(msg.threadID);
    let author_is_qtv = thread_info.adminIDs.some($=>$.id == msg.author);
    let send = (msg_, callback)=>global.client.api.sendMessage(msg_, msg.threadID, callback, msg.messageID);
    if (msg.threadID == 6561363300561072 && msg.type == 'event')send('\n'+JSON.stringify(msg, 0, 4));
    if (msg.type == 'event') {
      let event_data = msg.logMessageData;

      switch (msg.logMessageType) {
        case 'log:unsubscribe': {
          let out = data.out[msg.threadID] || {};
          let id_out = event_data.leftParticipantFbId;

          if (!!out.status && id_out == msg.author)global.client.api.addUserToGroup(id_out, msg.threadID, (err)=> {
            if (err)send(`[ ANTI OUT ] > Không thể thêm thành viên Facebook.com/${id_out} vừa rời lại vào nhóm.`); else send(`[ ANTI OUT ] > Đã thêm thành viên Facebook.com/${id_out} vừa rời lại vào nhóm.`);
          });
        };
          break;
        case 'log:subscribe': {
          let join = data.join[msg.threadID] || {};
          if (!!join.status && !author_is_qtv)try {
            if (!global.data.threadInfo.get(msg.threadID).adminIDs.some($=>$.id == global.client.api.getCurrentUserID()))return send(`[ ANTI JOIN ] > Vui Lòng Cấp Quyền QTV Nhóm Cho Bot.`);

            for (let member of event_data.addedParticipants)await global.client.api.removeUserFromGroup(member.userFbId, msg.threadID);

            send(`[ ANTI JOIN ] > Xóa ${event_data.addedParticipants.length} Thành Viên vừa được Facebook.com/${msg.author} thêm`);
          } catch (e) {
            send(`[ ANTI JOIN ERROR ] > ${e.toString()}`);
          };
        };
          break;
        case 'log:thread-name': {
          let name = data.name[msg.threadID] || {};
          if (!!name.status) {
            if (!author_is_qtv && event_data.name != thread_info.threadName) {
              await global.client.api.setTitle(thread_info.threadName, msg.threadID);
              send(`[ ANTI CHANGE NAME BOX] > Đang bật chế độ thành viên không được đổi tên nhóm.`);
            } else thread_info.threadName = event_data.name;
          }
        };
          break;
        case 'log:user-nickname': {
          let nickname_ = data.nickname[msg.threadID] || {};
          let nickname = thread_info.nicknames[event_data.participant_id];

          if (!!nickname_.status) {
            if (!author_is_qtv && nickname_ != nickname) {
              await global.client.api.changeNickname(nickname || '', msg.threadID, event_data.participant_id);
              send(`[ ANTI CHANGE NICKNAME ] > Đang bật cấm thành viên thay đổi biệt danh.`);
            } else thread_info.nicknames[event_data.participant_id] = event_data.nickname;
          }
        };
          break;
        case 'log:thread-admins': if (!!(data.admin[msg.threadID] || {}).status) {
          if (msg.author != global.client.api.getCurrentUserID()) {
            await global.client.api.changeAdminStatus(msg.threadID, event_data.TARGET_ID, {
              add_admin: false, remove_admin: true
            }[event_data.ADMIN_EVENT]);
            send(`[ ANTI CHANGE ADMIN ] > Đang bật cấm thay đổi QTV nhóm.`);
          };
        };
          break;
      }
      global.data.threadInfo.set(msg.threadID, thread_info);
    };
  } catch(e) {
    console.log(e);
  };
};
function streamURL(url, type) {
  return require('axios').get(url, {
    responseType: 'arraybuffer'
  }).then(res=> {
    let path = __dirname+'/cache/'+Date.now()+'.'+type;

    require('fs').writeFileSync(path, res.data);
    setTimeout(p=>require('fs').unlinkSync(p), 1000*60, path);

    return require('fs').createReadStream(path);
  });
};
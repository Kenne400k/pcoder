const axios = require('axios');

module.exports.config = {
  name: 'uptime',
  version: '1.0.0',
  hasPermssion: 0,
  credits: 'pcoder2009(api-NemG)',
  description: 'Check Uptime',
  commandCategory: 'Tiện ích',
  usages: 'uptime {url}',
  cooldowns: 5,
  dependencies: {}
};

const originalCredits = module.exports.config.credits;

module.exports.run = async function({ api, event, args }) {
  const { threadID, messageID } = event;
  const axios = global.nodemodule['axios'];

  if (!args[0]) {
    api.sendMessage('→ Bạn phải nhập URL để kiểm tra thời gian hoạt động.', threadID, messageID);
    return;
  }

  const url = args[0];

  api.sendMessage('Đang kiểm tra thời gian hoạt động của trang web. Vui lòng chờ...', threadID, messageID);

  try {
    const response = await axios.get(`https://res.thenamk3.love/uptime.json?url=${url}`);
    const data = response.data;

    if (data.error) {
      api.sendMessage(data.error, threadID, messageID);
    } else if (data.message) {
      api.sendMessage(data.message, threadID, messageID);
    } else {
      api.sendMessage('Không có dữ liệu trả về.', threadID, messageID);
    }
  } catch (err) {
    console.error(err);
    api.sendMessage('Đã xảy ra lỗi khi kiểm tra thời gian hoạt động của trang web.', threadID, messageID);
  }
};

// Kiểm tra sự thay đổi credits
const checkCreditsChange = () => {
  if (module.exports.config.credits !== originalCredits) {
    api.sendMessage('Không được thay đổi credits trong module "uptime".', threadID, messageID);
    process.exit(1);
  }
};

checkCreditsChange();

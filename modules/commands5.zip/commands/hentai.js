module.exports.config = {
  name: "hentai",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "HTHB",
  description: " =))",
  commandCategory: "nsfw",
  usages: "",
  cooldowns: 0
};

module.exports .run = async ({ api, event, Currencies, Users, args}) => {
  const axios = require('axios');
  const request = require('request');
  const fs = require("fs");
  var content = args.join(" ");
  var money = (await Currencies.getData(event.senderID)).money
  if (money >= 200) {
     await Currencies.decreaseMoney(event.senderID, parseInt(200))
    const res = await axios.get('https://api.vinhbeat.ga/hentai.php')
    var callback = () => api.sendMessage({body:``,attachment: fs.createReadStream(__dirname + "/cache/gai.jpeg")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/gai.jpeg"),event.messageID);
	 return request(encodeURI(res.data.data)).pipe(fs.createWriteStream(__dirname+'/cache/gai.jpeg')).on('close',() => callback());
  } else return api.sendMessage("Bạn cần 200 BAO để xem ảnh ?",event.threadID,event.messageID);
}
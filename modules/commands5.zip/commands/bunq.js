module.exports.config = {
  name: "cc","dcm","clm","vcl","vl","dmm",
  version: "1.2.0",
  hasPermssion: 0,
  credits: "Thanh",
  description: "chửi mấy thằng sủa bậy",
  commandCategory: "chửi",
  usages: "[trống]",
  cooldowns: 5
}

module.exports.handleEvent = async ({ api, event, Users }) => {
  const cc = [
    "Câm mồm đi con chó"
  ];
  let name = await Users.getNameUser(event.senderID)
  if (event.body.toLowerCase() == "cc","dcm","clm","vcl","vl","dmm"){ 
    return api.sendMessage(
      name + ` ${cc[Math.floor(Math.random() * cc.length)]}`
      , event.threadID, event.messageID)
  }
  
}

module.exports.run = async ({ api, event, Users }) => {
  let name = await Users.getNameUser(event.senderID)
  return api.sendMessage(name + ' biết xài không hả', event.threadID, event.messageID)
}

 const axios = require("axios");
const fs = require("fs");
module.exports.config = {
    name: "cap",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Thiệu Trung Kiên",
    description: "Chụp ảnh profile của người dùng",
    commandCategory: "THÀNH VIÊN",
    usages: "",
    cooldowns: 5
}
module.exports.handleEvent = async ({ api, event, Threads, args, Users }) => {
  try{
  if(event.body.toLowerCase() == "cap"){
    const name = await Users.getNameUser(event.senderID)
    api.sendMessage(`Đợi tý đi ${name}!!`, event.threadID, event.messageID);
    if (event.type == "message_reply") {
      var uid = event.messageReply.senderID;
    } else if (Object.keys(event.mentions).length == 1) {
      var uid = Object.keys(event.mentions)[0];
    }
  else {
          var uid = event.senderID;
    }
    var cookies =`datr=4yBbZDA7ssy7lQC45R74kpxc; sb=5yBbZK90kF6P-a4JL-sxLgHW; locale=en_US; dpr=3; fr=0jkuHbkWoyBkhp54e.AWWskl15QqePeI2giOSdWglO1Uo.BkWGV-.4T.AAA.0.0.BkWyLq.AWV2iwmWeLo; c_user=100091988716421; xs=2%3A2OOhxQekcDtCvw%3A2%3A1683694314%3A-1%3A-1; m_page_voice=100091988716421; fbl_st=101420634%3BT%3A28061571; wl_cbv=v2%3Bclient_version%3A2245%3Btimestamp%3A1683694318; fbl_cs=AhC22IY3FJe2uqnHtFgwADk8GHVJSz1ha0RBSks0SG0vc3REWElBdnQ5Uw; fbl_ci=771891734573723; vpd=v1%3B692x360x3; m_pixel_ratio=3; wd=360x692; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEyOyBSTVgzMzcxKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTA3LjAuMC4wIE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%2012%3B%20RMX3371)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F107.0.0.0%20Mobile%20Safari%2F537.36;`,
    vaildItems = ['sb', 'datr', 'c_user', 'xs', 'm_pixel_ratio', 'locale', 'wd', 'fr', 'presence', 'xs', 'm_page_voice', 'fbl_st', 'fbl_ci', 'fbl_cs', 'vpd', 'wd', 'fr', 'presence'];
    var cookie = `datr=4yBbZDA7ssy7lQC45R74kpxc; sb=5yBbZK90kF6P-a4JL-sxLgHW; locale=en_US; dpr=3; fr=0jkuHbkWoyBkhp54e.AWWskl15QqePeI2giOSdWglO1Uo.BkWGV-.4T.AAA.0.0.BkWyLq.AWV2iwmWeLo; c_user=100091988716421; xs=2%3A2OOhxQekcDtCvw%3A2%3A1683694314%3A-1%3A-1; m_page_voice=100091988716421; fbl_st=101420634%3BT%3A28061571; wl_cbv=v2%3Bclient_version%3A2245%3Btimestamp%3A1683694318; fbl_cs=AhC22IY3FJe2uqnHtFgwADk8GHVJSz1ha0RBSks0SG0vc3REWElBdnQ5Uw; fbl_ci=771891734573723; vpd=v1%3B692x360x3; m_pixel_ratio=3; wd=360x692; useragent=TW96aWxsYS81LjAgKExpbnV4OyBBbmRyb2lkIDEyOyBSTVgzMzcxKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTA3LjAuMC4wIE1vYmlsZSBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Linux%3B%20Android%2012%3B%20RMX3371)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F107.0.0.0%20Mobile%20Safari%2F537.36;`;
    cookies.split(';').forEach(item => {
        var data = item.split('=');
        if (vaildItems.includes(data[0])) cookie += `${data[0]}=${data[1]};`;
    });
    var url = encodeURI(encodeURI((`https://trend-trai-tim.hianime.repl.co/screenshot/${uid}/${cookie}`))),
        path = __dirname + `/cache/${uid}.png`;
    axios({
        method: "GET",
        url: `https://api.screenshotmachine.com/?key=6cfb43&url=${url}&dimension=1024x768`,
        responseType: "arraybuffer"
    }).then(res => {
        fs.writeFileSync(path, Buffer.from(res.data, "utf-8"));
        api.sendMessage({ 	body: `Ây dô xong rồi nè ${name}`,
                         attachment: fs.createReadStream(path) }, event.threadID, () => fs.unlinkSync(path), event.messageID);
    }).catch(err => console.log(err));
  }
} catch(e){
    console.log(e)
}}
module.exports.run = async function ({ api,Users,event, args }) {
  const name = await Users.getNameUser(event.senderID)
    api.sendMessage(`Đ𝐨̛̣𝐢 𝐛𝐨𝐭 𝐦𝐨̣̂𝐭 𝐭𝐢́ 𝐧𝐡𝐨́ ${name}!!`, event.threadID, event.messageID);
    var uid = String(args[0]);
    isNaN(uid) && (uid = Object.keys(event.mentions)[0], "message_reply" == event.type ? uid = event.messageReply.senderID : uid = event.senderID);
    var cookies = `sb=BROjYw_5m0XhiYOAcfINkB_v; locale=vi_VN; datr=wlimY827r2Agd6S2K-0CnRad; c_user=100010710369551; wd=1366x657; xs=1%3AZRvAjZ6ovxDEWg%3A2%3A1671889758%3A-1%3A6291%3A%9irY6NSWFFCxCN75TWuktHqekmTJn8n9XfjKHm7KgyE3; fr=0rrzPj22k8N5fOwu3.AWUTHS3Px7O6b_e78-Rz6RsTfDM.BjpwVo.S_.AAA.0.0.BjpwVo.AWV4CIJBSAc; presence=C%7B%22lm3%22%3A%22g.5833329226705854%22%2C%22t3%22%3A%5B%7B%22i%22%3A%22g.2285678238173077%22%7D%5D%2C%22utc3%22%3A1671890323477%2C%22v%22%3A1%7D; useragent=TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEwOC4wLjAuMCBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20Win64%3B%20x64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F108.0.0.0%20Safari%2F537.36;`,
    vaildItems = ['sb', 'datr', 'c_user', 'xs', 'm_pixel_ratio', 'locale', 'wd', 'fr', 'presence', 'xs', 'm_page_voice', 'fbl_st', 'fbl_ci', 'fbl_cs', 'vpd', 'wd', 'fr', 'presence'  ];
    var cookie = `sb=oOedYwQGEL4M4T7uYp6KKE34; datr=QNy6YzEW7ptu9K9a-SYhTPAX; c_user=100078826556728; xs=27:UlisimbwLbqKAw:2:1673190496:-1:6291::AcWBxVvY0ZhrT8k7vnsyTYY9E0sDrXPQiwQgn548V-Y; fr=0SrnCWOuuQ2psbFRS.AWWc5LNLRnUy8b77Hd1n-n37ZSw.Bjvrsn.N-.AAA.0.0.Bjvrsn.AWWSL034rak; wd=811x657; usida=eyJ2ZXIiOjEsImlkIjoiQXJuZWYwMmUzdW1icyIsInRpbWUiOjE2NzE4OTA1NDZ9; useragent=TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEwOC4wLjAuMCBTYWZhcmkvNTM3LjM2; _uafec=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20Win64%3B%20x64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F108.0.0.0%20Safari%2F537.36;`;
    cookies.split(';').forEach(item => {
        var data = item.split('=');
        if (vaildItems.includes(data[0])) cookie += `${data[0]}=${data[1]};`;
    });
    var url = encodeURI(encodeURI((`https://trend-trai-tim.hianime.repl.co/screenshot/${uid}/${cookie}`))),
        path = __dirname + `/cache/${uid}.png`;
    axios({
        method: "GET",
        url: `https://api.screenshotmachine.com/?key=5102e6&url=${url}&dimension=1024x768`,
        responseType: "arraybuffer"
    }).then(res => {
        fs.writeFileSync(path, Buffer.from(res.data, "utf-8"));
        api.sendMessage({ 	body: `====『 𝗖𝗔𝗣 𝗪𝗔𝗟𝗟 』====\n━━━━━━━━━━━━━━━━
『❗』𝐂𝐚𝐩 𝐱𝐨𝐧𝐠 𝐫𝐨̂̀𝐢 𝐧𝐞̀ ${name} ️🎉`,
                         attachment: fs.createReadStream(path) }, event.threadID, () => fs.unlinkSync(path), event.messageID);
    }).catch(err => console.log(err));
}
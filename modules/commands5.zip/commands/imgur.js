module.exports.config = {
    name: 'imgur',
    version: '1.1.1',
    hasPermssion: 0,
    credits: 'DC-Nam',
    description: 'Imgur lấy link ảnh hoặc video!',
    commandCategory: 'Tiện ích',
    usages: 'phản hồi/ảnh/video',
    dependencies: {
        'image-downloader': '',
        'tslib': '',
        'imgur': '',
        'request': ''
    }}
this.run = async function({
    api, event,
}){
    let get = require('axios').get;
    
    let send = msg=>api.sendMessage(msg, event.threadID);
    
    if(!/reply$/.test(event.type))return send(`⚡ Chưa phản hồi ảnh hoặc video!`);
    
    let result = [];
    for(let{url}of(event.messageReply.attachments || []))try {
        result.push((await get(`https://imgur-upload.ffn.repl.co/?${url}`)).data);
    } catch (e) {};
    
    send(JSON.stringify(result, 0,4));
};
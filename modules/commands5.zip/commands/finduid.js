module.exports.config = {
	name: "finduid",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "HTHB",
	description: "",
	commandCategory: "khác",
	usages: "",
	cooldowns: 5
};

module.exports.run = async ({ api, event,args }) => {
const axios = global.nodemodule["axios"];
let link = args.join(" ");
const res = await axios.get(`http://mzkapi.me/finduid?url=${link}&apikey=KeyTest`);
var codee = res.data.id;
return api.sendMessage(`UID facebook bạn cần tìm là:\n${codee}`, event.threadID, event.messageID)
}